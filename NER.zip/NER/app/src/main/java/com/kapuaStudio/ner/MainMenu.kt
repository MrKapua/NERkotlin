package com.kapuaStudio.ner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainMenu : AppCompatActivity()
{
    lateinit var barraMenu : ActionBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        barraMenu = supportActionBar!!
        var bottonNavigation: BottomNavigationView = findViewById(R.id.navigationViewMenu)
    }
}
